import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building, Users, Calendar, CreditCard, BarChart3, Settings, Bell, User, LogOut, Plus, Eye, Edit, Trash2, Phone, Mail, MapPin, Clock, DollarSign, CheckCircle, AlertCircle } from "lucide-react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const stats = [
    { title: "Total Clients", value: "124", icon: Users, color: "text-blue-600" },
    { title: "Active Services", value: "8", icon: Calendar, color: "text-green-600" },
    { title: "Monthly Revenue", value: "R 45,200", icon: DollarSign, color: "text-purple-600" },
    { title: "Pending Payments", value: "3", icon: CreditCard, color: "text-orange-600" },
  ];

  const recentClients = [
    { name: "Sarah Johnson", service: "Traditional Funeral", status: "Active", date: "2024-01-15", amount: "R 8,500" },
    { name: "Michael Smith", service: "Cremation Service", status: "Completed", date: "2024-01-12", amount: "R 5,200" },
    { name: "Emma Davis", service: "Memorial Service", status: "Pending", date: "2024-01-10", amount: "R 3,800" },
  ];

  const upcomingServices = [
    { client: "Robert Wilson", service: "Traditional Funeral", date: "2024-01-20", time: "10:00 AM" },
    { client: "Lisa Anderson", service: "Cremation", date: "2024-01-22", time: "2:00 PM" },
    { client: "David Brown", service: "Memorial", date: "2024-01-25", time: "11:00 AM" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link to="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-teal-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">R</span>
                </div>
                <span className="text-xl font-bold text-gray-900">ReposeLink</span>
              </Link>
              <Badge variant="secondary">Professional Plan</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <User className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <nav className="p-6">
            <div className="space-y-2">
              <Button variant="secondary" className="w-full justify-start">
                <BarChart3 className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Clients
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Calendar className="w-4 h-4 mr-2" />
                Services
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <CreditCard className="w-4 h-4 mr-2" />
                Payments
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Building className="w-4 h-4 mr-2" />
                Business Profile
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard Overview</h1>
            <p className="text-gray-600">Welcome back! Here's what's happening with your funeral home.</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">
                    {stat.title}
                  </CardTitle>
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Recent Clients */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Recent Clients</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Client
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentClients.map((client, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold">{client.name}</h4>
                        <p className="text-sm text-gray-600">{client.service}</p>
                        <p className="text-xs text-gray-500">{client.date}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant={client.status === 'Active' ? 'default' : client.status === 'Completed' ? 'secondary' : 'outline'}>
                          {client.status}
                        </Badge>
                        <p className="text-sm font-semibold mt-1">{client.amount}</p>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Services */}
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Services</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingServices.map((service, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold">{service.client}</h4>
                        <p className="text-sm text-gray-600">{service.service}</p>
                        <div className="flex items-center text-xs text-gray-500 mt-1">
                          <Calendar className="w-3 h-3 mr-1" />
                          {service.date}
                          <Clock className="w-3 h-3 ml-3 mr-1" />
                          {service.time}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Business Performance */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Business Performance</CardTitle>
              <CardDescription>Your business metrics for this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">Revenue Target</span>
                    <span className="text-sm font-semibold">75%</span>
                  </div>
                  <Progress value={75} className="mb-2" />
                  <p className="text-xs text-gray-500">R 45,200 of R 60,000</p>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">Client Satisfaction</span>
                    <span className="text-sm font-semibold">92%</span>
                  </div>
                  <Progress value={92} className="mb-2" />
                  <p className="text-xs text-gray-500">Excellent rating</p>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">Services Completed</span>
                    <span className="text-sm font-semibold">88%</span>
                  </div>
                  <Progress value={88} className="mb-2" />
                  <p className="text-xs text-gray-500">22 of 25 scheduled</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button className="h-20 flex flex-col bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700">
                  <Plus className="w-6 h-6 mb-2" />
                  Add Client
                </Button>
                <Button variant="outline" className="h-20 flex flex-col">
                  <Calendar className="w-6 h-6 mb-2" />
                  Schedule Service
                </Button>
                <Button variant="outline" className="h-20 flex flex-col">
                  <CreditCard className="w-6 h-6 mb-2" />
                  Process Payment
                </Button>
                <Button variant="outline" className="h-20 flex flex-col">
                  <BarChart3 className="w-6 h-6 mb-2" />
                  View Reports
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}